﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstString = Console.ReadLine();
            var firstStringArr = firstString.ToCharArray();

            string secondString = Console.ReadLine();
            var secondStringArr = secondString.ToCharArray();

            int lenghtFirst = firstString.Length;
            int lenghtTwo = 


        }
    }
}
