param([string]$Exercise='all',[switch]$List,[switch]$Interactive,[switch]$NoBuild)
$ErrorActionPreference='Stop'
$examples=Get-Content (Join-Path $PSScriptRoot 'exercises.json') -Raw|ConvertFrom-Json
if ($List) { $examples|Select-Object Name,Description,OriginalSource|Format-Table -Wrap; return }
if ($Exercise -eq 'menu') {
 for ($i=0;$i -lt $examples.Count;$i++) { Write-Host ("{0,2}. {1}: {2}" -f ($i+1),$examples[$i].Name,$examples[$i].Description) }
 $choice=Read-Host 'Choose an exercise number'
 $number=0
 if (![int]::TryParse($choice,[ref]$number) -or $number -lt 1 -or $number -gt $examples.Count) { throw 'Invalid selection.' }
 $Exercise=$examples[$number-1].Name
 $Interactive=$true
}
if ($Exercise -ne 'all' -and $Exercise -notin $examples.Name) { throw 'Unknown exercise; use -List.' }
if ($Interactive -and $Exercise -eq 'all') { throw 'Select one exercise for interactive input.' }
foreach($example in $examples) {
 if($Exercise -ne 'all' -and $Exercise -ne $example.Name){continue}
 Write-Host ("`n{0}: {1}" -f $example.Name,$example.Description)
 if(!$NoBuild) {
  & dotnet build (Join-Path $PSScriptRoot 'Exercises.csproj') "-p:Exercise=$($example.Name)" --nologo --verbosity quiet
  if($LASTEXITCODE -ne 0){throw "Build failed: $($example.Name)"}
 }
 $dll=Join-Path $PSScriptRoot "bin/$($example.Name)/net10.0/Exercises.dll"
 if(!(Test-Path -LiteralPath $dll)){throw 'Build missing; rerun without -NoBuild.'}
 if($Interactive){
  Write-Host $example.InputFormat
  & dotnet $dll
  if($LASTEXITCODE -ne 0){throw 'The exercise rejected the input.'}
 } else {
  $actual=($example.Input|& dotnet $dll|Out-String).Trim().Replace("`r`n","`n")
  if($LASTEXITCODE -ne 0 -or $actual -cne $example.Expected.Trim()){throw "Unexpected result for $($example.Name): $actual"}
  Write-Host ("PASS: "+$actual)
 }
}
