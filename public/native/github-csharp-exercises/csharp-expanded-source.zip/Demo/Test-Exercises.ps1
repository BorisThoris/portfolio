param([switch]$NoBuild,[string]$Output)
$ErrorActionPreference='Stop'
$examples=Get-Content (Join-Path $PSScriptRoot 'exercises.json') -Raw|ConvertFrom-Json
$results=@()
foreach($example in $examples){
 if(!$NoBuild){
  & dotnet build (Join-Path $PSScriptRoot 'Exercises.csproj') "-p:Exercise=$($example.Name)" --nologo --verbosity quiet
  if($LASTEXITCODE -ne 0){throw "Build failed: $($example.Name)"}
 }
 $dll=Join-Path $PSScriptRoot "bin/$($example.Name)/net10.0/Exercises.dll"
 $cases=@([pscustomobject]@{Name='demo';Input=$example.Input;Expected=$example.Expected;ExitCode=0})+@($example.Cases)
 foreach($case in $cases){
  $info=[Diagnostics.ProcessStartInfo]::new('dotnet')
  $info.ArgumentList.Add($dll)
  $info.UseShellExecute=$false
  $info.CreateNoWindow=$true
  $info.RedirectStandardInput=$true
  $info.RedirectStandardOutput=$true
  $info.RedirectStandardError=$true
  $process=[Diagnostics.Process]::Start($info)
  $stdout=$process.StandardOutput.ReadToEndAsync()
  $stderr=$process.StandardError.ReadToEndAsync()
  $process.StandardInput.WriteLine($case.Input)
  $process.StandardInput.Close()
  if(!$process.WaitForExit(10000)){ $process.Kill($true); throw "Timed out: $($example.Name)/$($case.Name)" }
  $actual=$stdout.GetAwaiter().GetResult().Trim().Replace("`r`n","`n")
  $errorText=$stderr.GetAwaiter().GetResult().Trim()
  $code=$process.ExitCode
  $process.Dispose()
  if($code -ne $case.ExitCode -or $actual -cne $case.Expected.Trim() -or ($code -ne 0 -and !$errorText)){
   throw "Failed $($example.Name)/$($case.Name): exit=$code, output=[$actual], stderr=[$errorText]"
  }
  $results+=[pscustomobject]@{Exercise=$example.Name;Case=$case.Name;ExitCode=$code;Output=$actual;Error=$errorText;Passed=$true}
 }
 Write-Host ("PASS {0}: {1} cases" -f $example.Name,$cases.Count)
}
if($Output){$results|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $Output -Encoding utf8}
Write-Host ("PASS: {0} programs, {1} native process cases." -f $examples.Count,$results.Count)

