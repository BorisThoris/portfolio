using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Reflection;

// Recovered implementations of the original exercises. Original files are preserved;
// Demo/exercises.json records the source mapping and each explicit input contract.
internal static class RecoveredProgram
{
    static int Main()
    {
        CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
        try
        {
            string exercise = Assembly.GetExecutingAssembly()
                .GetCustomAttributes<AssemblyMetadataAttribute>()
                .Single(x => x.Key == "Exercise").Value;
            switch (exercise)
            {
                case "circle-intersection": Circles(false); break;
                case "circle-six-values": Circles(true); break;
                case "date-workdays":
                case "workdays": Workdays(); break;
                case "master-numbers": MasterNumbers(); break;
                case "common-ends": CommonEnds(); break;
                case "rotation-sums": RotationSums(); break;
                case "char-arrays": CharacterArrays(); break;
                case "positive-sequences": PositiveSequences(); break;
                case "substring": Substrings(); break;
                case "sequence-commands": SequenceCommands(); break;
                case "instructions": Instructions(); break;
                default: throw new ArgumentException("Unknown recovered exercise.");
            }
            return 0;
        }
        catch (Exception error) when (error is ArgumentException || error is FormatException
            || error is OverflowException)
        {
            Console.Error.WriteLine("Input error: " + error.Message);
            return 1;
        }
    }

    static string Line() => Console.ReadLine() ?? throw new ArgumentException("Unexpected end of input.");
    static string[] Words(string line) => line.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
    static int Count(string line, int maximum = 1000000)
    {
        if (!int.TryParse(line, out int value) || value < 0 || value > maximum)
            throw new ArgumentException($"Enter a whole number from 0 to {maximum}.");
        return value;
    }

    static BigInteger[] ReadCircle(bool separateLines)
    {
        var values = separateLines ? new[] { Line(), Line(), Line() } : Words(Line());
        if (values.Length != 3) throw new ArgumentException("A circle needs x y radius.");
        var circle = values.Select(BigInteger.Parse).ToArray();
        if (circle[2] < 0) throw new ArgumentException("Radius cannot be negative.");
        return circle;
    }
    static void Circles(bool separateLines)
    {
        var first = ReadCircle(separateLines);
        var second = ReadCircle(separateLines);
        BigInteger dx = second[0] - first[0], dy = second[1] - first[1];
        BigInteger radii = first[2] + second[2];
        Console.WriteLine(dx * dx + dy * dy <= radii * radii ? "Yes" : "No");
    }

    static DateTime Date(string text)
    {
        if (!DateTime.TryParseExact(text.Trim(), "dd-MM-yyyy", CultureInfo.InvariantCulture,
            DateTimeStyles.None, out var date)) throw new ArgumentException("Use dd-MM-yyyy dates.");
        return date;
    }
    static void Workdays()
    {
        var start = Date(Line());
        var end = Date(Line());
        if (start > end) throw new ArgumentException("The end date must not precede the start.");
        int inclusive = (end - start).Days + 1;
        int total = inclusive / 7 * 5;
        for (int offset = 0; offset < inclusive % 7; offset++)
        {
            var day = start.AddDays(offset).DayOfWeek;
            if (day != DayOfWeek.Saturday && day != DayOfWeek.Sunday) total++;
        }
        // Optional third line supplies explicit holidays; there is no implicit country calendar.
        foreach (var holiday in Words(Console.ReadLine() ?? "").Select(Date).Distinct())
            if (holiday >= start && holiday <= end && holiday.DayOfWeek != DayOfWeek.Saturday
                && holiday.DayOfWeek != DayOfWeek.Sunday) total--;
        Console.WriteLine(total);
    }

    static void MasterNumbers()
    {
        int limit = Count(Line());
        for (int number = 1; number <= limit; number++)
        {
            string digits = number.ToString(CultureInfo.InvariantCulture);
            if (digits.SequenceEqual(digits.Reverse()) && digits.Sum(c => c - '0') % 7 == 0
                && digits.Any(c => (c - '0') % 2 == 0))
                Console.WriteLine(number);
        }
    }

    static void CommonEnds()
    {
        var first = Words(Line()); var second = Words(Line());
        int size = Math.Min(first.Length, second.Length), left = 0, right = 0;
        while (left < size && first[left] == second[left]) left++;
        while (right < size && first[first.Length - right - 1] == second[second.Length - right - 1]) right++;
        Console.WriteLine(Math.Max(left, right));
    }

    static void RotationSums()
    {
        var numbers = Words(Line()).Select(BigInteger.Parse).ToArray();
        int rotations = Count(Line(), 1000000000);
        if (numbers.Length == 0) throw new ArgumentException("Provide at least one number.");
        // Whole cycles contribute the same total to each position.
        var cycleSum = numbers.Aggregate(BigInteger.Zero, (sum, value) => sum + value);
        var sums = Enumerable.Repeat(cycleSum * (rotations / numbers.Length), numbers.Length).ToArray();
        int remainder = rotations % numbers.Length;
        BigInteger window = BigInteger.Zero;
        for (int turn = 1; turn <= remainder; turn++) window += numbers[numbers.Length - turn];
        for (int index = 0; index < numbers.Length; index++)
        {
            sums[index] += window;
            window += numbers[index] - numbers[(index - remainder + numbers.Length) % numbers.Length];
        }
        Console.WriteLine(string.Join(" ", sums));
    }

    static void CharacterArrays()
    {
        // Inferred completion of the truncated ConsoleApp1 character-array comparison.
        string first = Line(), second = Line();
        if (string.CompareOrdinal(first, second) <= 0) Console.WriteLine(first + "\n" + second);
        else Console.WriteLine(second + "\n" + first);
    }

    static void PositiveSequences()
    {
        int count = Count(Line(), 10000);
        for (int sequence = 0; sequence < count; sequence++)
        {
            var numbers = Words(Line()).Select(BigInteger.Parse).ToArray();
            var output = new List<BigInteger>();
            for (int index = 0; index < numbers.Length; index++)
            {
                BigInteger value = numbers[index];
                if (value <= 0 && index + 1 < numbers.Length) value += numbers[++index];
                if (value > 0) output.Add(value);
            }
            Console.WriteLine(output.Count > 0 ? string.Join(" ", output) : "(empty)");
        }
    }

    static void Substrings()
    {
        string text = Line();
        int length = Count(Line());
        if (length == 0) throw new ArgumentException("Substring length must be positive.");
        bool found = false;
        for (int index = 0; index < text.Length; index++)
            if (text[index] == 'p')
            {
                int take = Math.Min(length, text.Length - index);
                Console.WriteLine(text.Substring(index, take));
                index += take - 1;
                found = true;
            }
        if (!found) Console.WriteLine("no");
    }

    static void SequenceCommands()
    {
        int count = Count(Line(), 100000);
        var values = Words(Line()).Select(long.Parse).ToArray();
        if (count == 0 || values.Length != count) throw new ArgumentException("Array count must match a nonempty array.");
        string line;
        while ((line = Console.ReadLine()) != null)
        {
            var parts = Words(line);
            if (parts.Length == 0) continue;
            string command = parts[0].ToLowerInvariant();
            if (command == "over") break;
            if (command == "substract") command = "subtract";
            if (command == "lshift" || command == "rshift")
            {
                if (parts.Length != 1) throw new ArgumentException("A shift takes no arguments.");
                if (command == "lshift")
                {
                    long first = values[0];
                    Array.Copy(values, 1, values, 0, count - 1);
                    values[count - 1] = first;
                }
                else
                {
                    long last = values[count - 1];
                    Array.Copy(values, 0, values, 1, count - 1);
                    values[0] = last;
                }
            }
            else if (command == "add" || command == "subtract" || command == "multiply")
            {
                // Accept original two-line command/arguments and convenient single-line input.
                var operands = parts.Length == 1 ? Words(Line()) : parts.Skip(1).ToArray();
                if (operands.Length != 2) throw new ArgumentException("Use command zero-based-index amount.");
                int index = int.Parse(operands[0]); long amount = long.Parse(operands[1]);
                if (index < 0 || index >= count) throw new ArgumentException("Array index is out of range.");
                values[index] = command switch {
                    "add" => checked(values[index] + amount),
                    "subtract" => checked(values[index] - amount),
                    _ => checked(values[index] * amount)
                };
            }
            else throw new ArgumentException("Use add, subtract, multiply, lshift, rshift or over.");
            Console.WriteLine(string.Join(" ", values));
        }
    }

    static void Instructions()
    {
        string line;
        while ((line = Console.ReadLine()) != null)
        {
            var parts = Words(line);
            if (parts.Length == 0) continue;
            string command = parts[0].ToUpperInvariant();
            if (command == "END") break;
            int required = command == "INC" || command == "DEC" ? 2 : 3;
            if (parts.Length != required) throw new ArgumentException("Wrong operand count.");
            BigInteger first = BigInteger.Parse(parts[1]);
            BigInteger second = required == 3 ? BigInteger.Parse(parts[2]) : BigInteger.Zero;
            Console.WriteLine(command switch {
                "INC" => first + 1, "DEC" => first - 1, "ADD" => first + second,
                "MLA" => first * second, _ => throw new ArgumentException("Use INC, DEC, ADD, MLA or end.")
            });
        }
    }
}
