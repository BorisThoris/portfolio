$ErrorActionPreference='Stop'
$entries=Get-Content (Join-Path $PSScriptRoot 'exercises.json') -Raw|ConvertFrom-Json
Write-Host ("Recovered native C# catalog: {0} source entries" -f $entries.Count)
Write-Host 'Original files preserved; corrected implementations are explicitly mapped.'
for($i=0;$i -lt $entries.Count;$i++){
 $note=if($entries[$i].Inferred){' [inferred completion]'}else{''}
 Write-Host ("{0,2}. {1}{2}" -f ($i+1),$entries[$i].Name,$note)
}
Write-Host ''
Write-Host 'Representative native runs from the same launcher:'
foreach($name in @('circle-intersection','workdays','rotation-sums','instructions')){
 $dll=Join-Path $PSScriptRoot "bin/$name/net10.0/Exercises.dll"
 & (Join-Path $PSScriptRoot 'Run-Demo.ps1') -Exercise $name -NoBuild:(Test-Path -LiteralPath $dll)
}
Write-Host ''
Write-Host 'Interactive menu: ./Demo/Run-Demo.ps1 -Exercise menu'
Write-Host 'Full checks: ./Demo/Test-Exercises.ps1 (16 programs / 61 cases)'

