﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arrayNums = Console.ReadLine().Split(' ').ToArray();
            int numberOfRots = int.Parse(Console.ReadLine());
            int len = arrayNums.Length;
            string tmp = "sad";
            int sumFirst = 0;
            int[] inBetweenSum = new int[len];
            int sumLast = 0;

                 
                //rotate to the right
                for (int NumberOfRotsss = 0; NumberOfRotsss < numberOfRots; NumberOfRotsss++)
                {
                    tmp = arrayNums[len - 1];
                    sumFirst += int.Parse(tmp);

                    for (int i = len - 1; i > 0; i--)
                    {
                        arrayNums[i] = arrayNums[i - 1];
                        inBetweenSum[i] += int.Parse(arrayNums[i]);
                    }
                    arrayNums[0] = tmp;
                    sumLast += int.Parse(arrayNums[len - 1]);
                }

                //print end
                Console.Write(sumFirst);
                for (int i = 1; i < len - 1 ; i++)
                {
                    Console.Write($" {inBetweenSum[i]}");
                }
                Console.WriteLine($" {sumLast}");
            }

            
        }
    }

