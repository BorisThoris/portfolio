﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _13.Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            if (!int.TryParse(Console.ReadLine(), out n) || n < 0 || n > 10000)
            {
                Console.Error.WriteLine("Enter a whole number from 0 to 10000.");
                Environment.ExitCode = 1;
                return;
            }
            BigInteger sum = 1;
            for (BigInteger i = n; i > 0; i--)
            {
                sum *= i;
            }
            Console.WriteLine(sum);
        }
    }
}
