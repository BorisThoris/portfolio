# Recovered C# exercise collection

All 16 historical program source files now have native .NET console launcher entries. The original Visual Studio projects and exercise files are preserved. Four previously refined programs compile directly; 12 remaining source entries map to corrected implementations in `Demo/Recovered/Program.cs`. The two old workday sources share one implementation. The nested `Boris-rep` is a separate repository and remains separate.

## Run

Requires the installed .NET 10 SDK and PowerShell 7 (`pwsh`):

```powershell
./Demo/Run-Demo.ps1                 # Build and verify all 16 sample runs
./Demo/Run-Demo.ps1 -List           # Show names and original source mapping
./Demo/Run-Demo.ps1 -Exercise menu  # Choose one, then enter its input
./Demo/Run-Demo.ps1 -Exercise instructions -Interactive
./Demo/Test-Exercises.ps1           # Builds and checks 61 native process cases
```

After building, add `-NoBuild` for quick repeated samples. Each entry builds into its own `Demo/bin/<exercise>/net10.0/Exercises.dll`. You can also pipe your own input directly to that DLL; invalid input writes a diagnostic to stderr and exits 1. `exercises.json` contains exact input descriptions, sample data and edge checks.

## Source inventory

| Launcher name | Preserved original source | Recovered behavior |
| --- | --- | --- |
| factorial | 13. Factorial/13. Factorial/Program.cs | 20! using arbitrary precision |
| last-digit | 03 name of last digit number/03 name of last digit number/Program.cs | Last digit name, including long.MinValue |
| trailing-zeroes | 14. Factorial Trailing Zeroes/14. Factorial Trailing Zeroes/Program.cs | Factorial trailing zeros without constructing factorial |
| geometry | 12. Master Number.cs | Invariant-culture shape areas |
| circle-intersection | 0.3 inersection of circles yes or no.cs | Check overlap of two independently read disks |
| circle-six-values | 2. Advertisement Message/2. Advertisement Message/Program.cs | Complete the circle-input fragment (folder name is historical) |
| date-workdays | 01. Difference between dates.cs | Count inclusive weekdays, optional explicit holidays |
| workdays | 03 workdays between/03 workdays between/Program.cs | Recovered duplicate workday project, including holiday deduplication |
| master-numbers | Master/13. Factorial/Program.cs | Palindromes whose digit sum is divisible by seven and contain an even digit |
| common-ends | ConsoleApp2/ConsoleApp2/Program.cs | Largest equal prefix or suffix of two word arrays |
| rotation-sums | ConsoleApp3/ConsoleApp3/Program.cs | Sum successive right rotations; whole cycles handled directly |
| char-arrays | ConsoleApp1/ConsoleApp1/Program.cs | Inferred recovery: ordinal lexicographic order for two character strings |
| positive-sequences | 15. debugging/BePositive_broken.cs | Emit positive values; pair nonpositive values with the following item |
| substring | 15. debugging/Substring_broken.cs | Print non-overlapping substrings beginning at Latin p, safely clamped at end |
| sequence-commands | 15. debugging/SequenceOfCommands_broken.cs | Apply arithmetic once; circular shifts mutate the original sequence |
| instructions | 15. debugging/InstructionSet_broken.cs | INC/DEC/ADD/MLA command interpreter without overflow or infinite loop |
## Recovery decisions and limits

- **char-arrays** is an explicitly inferred completion: `ConsoleApp1` ends midway through a variable declaration after reading two character arrays. The recovered command prints the two input strings in ordinal lexicographic order. No original expected output existed to prove that contract.
- **circle-six-values** completes the unfinished circle input code; its historical folder is named “Advertisement Message”, but the actual source only defines circles. No advertisement generator was invented.
- **common-ends** makes the two word-array traversal attempts a defined largest-common-prefix-or-suffix exercise.
- Circle intersection means overlapping disks (including containment/tangency), matching the original distance <= radii-sum comparison. Inputs use independent arbitrary-precision coordinates/radii; negative radii are rejected.
- Workdays include both endpoints, exclude Saturday/Sunday, and optionally accept explicit holidays on a third line (press Enter for none). Duplicate/weekend holidays are not subtracted twice. No legal or national holiday calendar is assumed.
- Sequence arithmetic uses zero-based indices, accepts original two-line command/argument input and single-line commands, rotates cyclically, mutates once and detects signed-64-bit overflow.
- The positive-sequences recovery follows the source's strict positive-value rule; a nonpositive item consumes the following item if present. Substring search corrects the accidental Cyrillic character to Latin `p` and safely clamps the final substring.
- Instruction commands advance until `end` or EOF and use arbitrary-precision arithmetic. Rotation sums use complete cycles and a linear sliding window, so a billion rotations or a 10,000-element near-full cycle does not create a quadratic loop.
- Master-number input is limited to 1,000,000 to keep this brute-force exercise responsive.

Native builds completed with zero warnings/errors. The 61 process checks include empty/one-element data, negative and malformed inputs, leap/weekend dates, duplicate holidays, large integers, command EOF and invalid indices/overflow. Original source defects remain available for historical study; the launcher clearly maps to corrected code. `Nested Dictionary.txt` contains only an old build log, not recoverable source. No remote push was performed.