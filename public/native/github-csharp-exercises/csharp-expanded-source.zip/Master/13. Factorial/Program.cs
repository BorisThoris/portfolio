﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13.Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {

                if (Palindrome(i) == true && SumOfDigits(i) % 7 == 0 && ContainsEvenDigit(i) == true)
                {
                    Console.WriteLine(i);
                }



            }
        }


        static public double SumOfDigits(int i)
        {
            double sum = 0;
            while (i != 0)
            {
                sum += i % 10;
                i /= 10;
            }
            return sum;
        }

        static public bool ContainsEvenDigit(int i)
        {
            bool trueOrFalse = false;

            string iString = i.ToString();
            int lenght = iString.Length;
            for (int digit = 0; digit < lenght; digit++)
            {
                char digitS = iString[digit];
                int val = Convert.ToInt32(digitS);
                if (val % 2 == 0) { trueOrFalse = true; return trueOrFalse; }
            }
            return trueOrFalse;
        }




        static public bool Palindrome(int i)
        {
            bool Palindrome = false;
            int num = i;
            int t = num;
            int a, s = 0;
            while (num > 0)
            {
                a = num % 10;
                s = s * 10 + a;
                num = num / 10;

                if (t == s) { Palindrome = true; return (Palindrome); }
            }
            return (Palindrome);
        }
    }
}
