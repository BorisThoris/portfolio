﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


namespace ConsoleApp24
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger parsed;
            if (!BigInteger.TryParse(Console.ReadLine(), out parsed))
            {
                Console.Error.WriteLine("Enter a whole number.");
                Environment.ExitCode = 1;
                return;
            }
            int num = (int)(BigInteger.Abs(parsed) % 10);
            Method(num);
        }
        static void Method(long num)
        {
            switch ((ulong)num % 10)
            {
                case (1):
                    Console.WriteLine("one");
                    return;
                case (2):
                    Console.WriteLine("two");
                    return;
                case (3):
                    Console.WriteLine("three");
                    return;
                case (4):
                    Console.WriteLine("four");
                    return;
                case (5):
                    Console.WriteLine("five");
                    return;
                case (6):
                    Console.WriteLine("six");
                    return;

                case (7):
                    Console.WriteLine("seven");
                    return;
                case (8):
                    Console.WriteLine("eight");
                    return;
                case (9):
                    Console.WriteLine("nine");
                    return;
                case (0):
                    Console.WriteLine("zero");
                    return;
            }

        }

    }
}
