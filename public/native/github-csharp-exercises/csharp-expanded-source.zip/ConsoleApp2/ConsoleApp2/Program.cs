﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstInput = Console.ReadLine();
            string[] firstArray = firstInput.Split(' ');


            string secondInput = Console.ReadLine();
            string[] secondArray = secondInput.Split(' ');


            int firstLenght = firstArray.Length;
            int secondLength = secondArray.Length;

            int randomCount = 0;


            // if they have even sizes
            if (firstLenght == secondLength)
            {
                for (int NumberToPull = 0; NumberToPull < firstLenght; NumberToPull++)
                {
                    if (firstArray[NumberToPull] == secondArray[NumberToPull]) { randomCount++; }
                }
            }


            //if they have uneven sizes
            if (firstLenght > secondLength)
            {

                //reading from left to right untill end of shorter one
                for (int NumberToPull = 0; NumberToPull < secondLength - 2; NumberToPull++)
                {
                    if (firstArray[NumberToPull] == secondArray[NumberToPull]) { randomCount++; }
                }

                //reading from right to left untill start of shorter one
                for (int NumberFromSmalleArr = secondLength - 2; NumberFromSmalleArr >= 0; NumberFromSmalleArr--)
                {
                    for (int NumberFromBiggerArr = firstLenght - 1; NumberFromBiggerArr >= NumberFromSmalleArr; NumberFromBiggerArr--)
                    {
                        if (firstArray[NumberFromBiggerArr] == secondArray[NumberFromSmalleArr]) { randomCount++; }
                    }
                }
            }

            if (firstLenght < secondLength)
            {
                //reading from left to right untill end of shorter one
                for (int secondChar = 0; secondChar < firstLenght - 2; secondChar++)
                {
                    if (firstArray[secondChar] == secondArray[secondChar]) { randomCount++; }
                }

                //reading from right to left untill start of shorter one
                for (int secondFromArray = firstLenght - 2; secondFromArray >= 0; secondFromArray--)
                {
                    for (int firstFromArray = secondLength - 2; firstFromArray >= secondFromArray; firstFromArray--)
                    {
                        if (firstArray[firstFromArray] == secondArray[secondFromArray]) { randomCount++; }
                    }
                }
            }



            Console.WriteLine(randomCount);
        }
    }
}
