﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Advertisement_Message
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Circle circle1 = new Circle();
            int circle1Radius = circle1.radius;
            int circle1X = circle1.x;
            int circle1Y = circle1.y;
            
            Circle circle2 = new Circle();
            int circle2Radius = circle2.radius;
            int circle2X = circle2.x;
            int circle2Y = circle2.y;
            double d = Math.Sqrt(Math.Pow(Math.Abs(circle2X-circle1X),2)+Math.Pow(Math.Abs(circle2Y-circle1Y), 2));
            if (d <= circle1.radius + circle2.radius) { Console.WriteLine("Yes"); } else Console.WriteLine("No");
            
        }
        
    }
    public class Circle
    {

        static List<string> variables = Console.ReadLine().Split(' ').ToList();
        
        public int x = int.Parse(variables[0]);
        public int y = int.Parse(variables[1]);
        public int radius = int.Parse(variables[2]);
        
        
       
        
    }
}
