﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _13.Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger n;
            if (!BigInteger.TryParse(Console.ReadLine(), out n) || n < 0)
            {
                Console.Error.WriteLine("Enter a nonnegative whole number.");
                Environment.ExitCode = 1;
                return;
            }
            BigInteger count = 0;
            while (n > 0)
            {
                n /= 5;
                count += n;
            }
            Console.WriteLine(count);

        }

        static BigInteger TrailingZeroCounter(BigInteger sum)
        {
            BigInteger countTrailingZeroes = 0;
            while (sum % 10 == 0)
            {
                countTrailingZeroes++;
                sum = sum / 10;
            }
            return (countTrailingZeroes);
        }

    }
}
