﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ConsoleApp29
{
    class Program
    {
        static void Main(string[] args)
        {
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            try
            {
                string figureType = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
                switch (figureType)
                {
                    case "triangle": Triangle(); break;
                    case "square": Square(); break;
                    case "rectangle": Rectangle(); break;
                    case "circle": Circle(); break;
                    default: throw new ArgumentException("Choose triangle, square, rectangle, or circle.");
                }
            }
            catch (ArgumentException error)
            {
                Console.Error.WriteLine(error.Message);
                Environment.ExitCode = 1;
            }
        }
        static double Dimension()
        {
            double value;
            if (!double.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out value)
                || double.IsNaN(value) || double.IsInfinity(value) || value <= 0 || value > 1e150)
                throw new ArgumentException("Enter a positive finite dimension no larger than 1e150.");
            return value;
        }
        static void Triangle()
        {
            double side = Dimension();
            double height = Dimension();
            Console.WriteLine($"{((side * height) / 2.0):F2}");
        }

        static void Square()
        {
            double side = Dimension();
            Console.WriteLine($"{(Math.Pow(side,2)):F2}");
        }

        static void Rectangle()
        {
            double width = Dimension();
            double height = Dimension();
            Console.WriteLine($"{(width * height):F2}");
        }

        static void Circle()
        {
            double radius = Dimension();
            Console.WriteLine($"{(Math.PI * Math.Pow(radius,2)):F2}");
        }
    }
}
