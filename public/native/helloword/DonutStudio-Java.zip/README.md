# Donut Studio — native Java / Swing

Run with Java 11 or newer:

```powershell
java -jar DonutStudio.jar
```

The real Swing app includes a resizable Java2D canvas, ring-spacing slider, keyboard control, and reset. There is no browser runtime.

Capture three native Swing views:

```powershell
java -jar DonutStudio.jar --capture captures
```

Capture a repeatable six-second sequence of the actual Swing UI:

```powershell
java -jar DonutStudio.jar --capture-frames frames
ffmpeg -framerate 10 -i frames/frame-%04d.png -vf "pad=ceil(iw/2)*2:ceil(ih/2)*2" -c:v libx264 -pix_fmt yuv420p -movflags +faststart donut-studio.mp4
```

The app opens its normal native window, varies the actual slider model and captures its Swing content. These are native UI frames, not a recreated website. `donut-studio-native.mp4` and `donut-spacing-*.png` are the verified portfolio assets.
